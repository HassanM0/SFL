This code summarizes the setup for the simulation in the paper: Strategic Federated Learning: Application to Smart-Meter Data Clustering". Link:
